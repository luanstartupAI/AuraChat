from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity, get_jwt
import datetime
import uuid
import bcrypt
import re
import logging

logger = logging.getLogger(__name__)

auth_bp = Blueprint('auth', __name__)

# Simulação de banco de dados de usuários para o projeto completo
users_db = {
    'admin@aura.com': {
        'id': 'user1',
        'email': 'admin@aura.com',
        'password': bcrypt.hashpw('admin123'.encode('utf-8'), bcrypt.gensalt()).decode('utf-8'),
        'name': 'Administrador',
        'role': 'admin',
        'avatar': None,
        'created_at': '2025-06-01T10:00:00Z',
        'last_login': None,
        'settings': {
            'theme': 'light',
            'notifications': True,
            'language': 'pt-BR'
        },
        'permissions': ['read', 'write', 'delete', 'admin'],
        'active': True
    }
}

# Simulação de tokens de refresh
refresh_tokens_db = {}

# Validação de email
def is_valid_email(email):
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email) is not None

# Validação de senha
def is_valid_password(password):
    # Pelo menos 8 caracteres, uma letra maiúscula, uma minúscula e um número
    if len(password) < 8:
        return False, "A senha deve ter pelo menos 8 caracteres"
    
    if not any(c.isupper() for c in password):
        return False, "A senha deve conter pelo menos uma letra maiúscula"
    
    if not any(c.islower() for c in password):
        return False, "A senha deve conter pelo menos uma letra minúscula"
    
    if not any(c.isdigit() for c in password):
        return False, "A senha deve conter pelo menos um número"
    
    return True, ""

@auth_bp.route('/login', methods=['POST'])
def login():
    try:
        data = request.get_json()
        
        if not data or 'email' not in data or 'password' not in data:
            return jsonify({'status': 'error', 'message': 'Email e senha são obrigatórios'}), 400
        
        email = data['email'].lower()
        password = data['password']
        
        if email not in users_db:
            logger.warning(f"Tentativa de login com email não cadastrado: {email}")
            return jsonify({'status': 'error', 'message': 'Credenciais inválidas'}), 401
        
        user = users_db[email]
        
        if not user['active']:
            logger.warning(f"Tentativa de login em conta inativa: {email}")
            return jsonify({'status': 'error', 'message': 'Conta desativada. Entre em contato com o suporte.'}), 403
        
        if not bcrypt.checkpw(password.encode('utf-8'), user['password'].encode('utf-8')):
            logger.warning(f"Tentativa de login com senha incorreta: {email}")
            return jsonify({'status': 'error', 'message': 'Credenciais inválidas'}), 401
        
        # Atualizar último login
        now = datetime.datetime.utcnow().isoformat() + 'Z'
        users_db[email]['last_login'] = now
        
        # Criar tokens JWT
        access_token = create_access_token(
            identity=email,
            additional_claims={
                'user_id': user['id'],
                'name': user['name'],
                'role': user['role'],
                'permissions': user['permissions']
            }
        )
        
        # Criar refresh token
        refresh_token_id = str(uuid.uuid4())
        refresh_tokens_db[refresh_token_id] = {
            'user_email': email,
            'created_at': now,
            'expires_at': (datetime.datetime.utcnow() + datetime.timedelta(days=30)).isoformat() + 'Z'
        }
        
        logger.info(f"Login bem-sucedido: {email}")
        
        return jsonify({
            'status': 'success',
            'message': 'Login realizado com sucesso',
            'access_token': access_token,
            'refresh_token': refresh_token_id,
            'user': {
                'id': user['id'],
                'email': email,
                'name': user['name'],
                'role': user['role'],
                'avatar': user['avatar'],
                'settings': user['settings']
            }
        })
    except Exception as e:
        logger.error(f"Erro no login: {str(e)}")
        return jsonify({'status': 'error', 'message': 'Erro interno do servidor'}), 500

@auth_bp.route('/register', methods=['POST'])
def register():
    try:
        data = request.get_json()
        
        if not data or 'email' not in data or 'password' not in data or 'name' not in data:
            return jsonify({'status': 'error', 'message': 'Dados incompletos'}), 400
        
        email = data['email'].lower()
        password = data['password']
        name = data['name']
        
        # Validar email
        if not is_valid_email(email):
            return jsonify({'status': 'error', 'message': 'Email inválido'}), 400
        
        # Validar senha
        is_valid, password_error = is_valid_password(password)
        if not is_valid:
            return jsonify({'status': 'error', 'message': password_error}), 400
        
        if email in users_db:
            logger.warning(f"Tentativa de registro com email já cadastrado: {email}")
            return jsonify({'status': 'error', 'message': 'Email já cadastrado'}), 409
        
        # Hash da senha
        hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
        
        # Criar novo usuário
        now = datetime.datetime.utcnow().isoformat() + 'Z'
        user_id = str(uuid.uuid4())
        
        users_db[email] = {
            'id': user_id,
            'email': email,
            'password': hashed_password,
            'name': name,
            'role': 'user',
            'avatar': None,
            'created_at': now,
            'last_login': now,
            'settings': {
                'theme': 'light',
                'notifications': True,
                'language': 'pt-BR'
            },
            'permissions': ['read', 'write'],
            'active': True
        }
        
        # Criar token JWT
        access_token = create_access_token(
            identity=email,
            additional_claims={
                'user_id': user_id,
                'name': name,
                'role': 'user',
                'permissions': ['read', 'write']
            }
        )
        
        # Criar refresh token
        refresh_token_id = str(uuid.uuid4())
        refresh_tokens_db[refresh_token_id] = {
            'user_email': email,
            'created_at': now,
            'expires_at': (datetime.datetime.utcnow() + datetime.timedelta(days=30)).isoformat() + 'Z'
        }
        
        logger.info(f"Novo usuário registrado: {email}")
        
        return jsonify({
            'status': 'success',
            'message': 'Usuário registrado com sucesso',
            'access_token': access_token,
            'refresh_token': refresh_token_id,
            'user': {
                'id': user_id,
                'email': email,
                'name': name,
                'role': 'user',
                'avatar': None,
                'settings': users_db[email]['settings']
            }
        }), 201
    except Exception as e:
        logger.error(f"Erro no registro: {str(e)}")
        return jsonify({'status': 'error', 'message': 'Erro interno do servidor'}), 500

@auth_bp.route('/refresh', methods=['POST'])
def refresh():
    try:
        data = request.get_json()
        
        if not data or 'refresh_token' not in data:
            return jsonify({'status': 'error', 'message': 'Token de atualização é obrigatório'}), 400
        
        refresh_token = data['refresh_token']
        
        if refresh_token not in refresh_tokens_db:
            logger.warning(f"Tentativa de refresh com token inválido")
            return jsonify({'status': 'error', 'message': 'Token de atualização inválido'}), 401
        
        token_data = refresh_tokens_db[refresh_token]
        email = token_data['user_email']
        
        # Verificar se o token expirou
        expires_at = datetime.datetime.fromisoformat(token_data['expires_at'].replace('Z', '+00:00'))
        if datetime.datetime.utcnow() > expires_at:
            # Remover token expirado
            refresh_tokens_db.pop(refresh_token, None)
            logger.warning(f"Tentativa de refresh com token expirado: {email}")
            return jsonify({'status': 'error', 'message': 'Token de atualização expirado'}), 401
        
        if email not in users_db:
            # Remover token órfão
            refresh_tokens_db.pop(refresh_token, None)
            logger.warning(f"Tentativa de refresh com usuário inexistente: {email}")
            return jsonify({'status': 'error', 'message': 'Usuário não encontrado'}), 401
        
        user = users_db[email]
        
        if not user['active']:
            logger.warning(f"Tentativa de refresh para conta inativa: {email}")
            return jsonify({'status': 'error', 'message': 'Conta desativada. Entre em contato com o suporte.'}), 403
        
        # Criar novo access token
        access_token = create_access_token(
            identity=email,
            additional_claims={
                'user_id': user['id'],
                'name': user['name'],
                'role': user['role'],
                'permissions': user['permissions']
            }
        )
        
        logger.info(f"Token atualizado para: {email}")
        
        return jsonify({
            'status': 'success',
            'message': 'Token atualizado com sucesso',
            'access_token': access_token
        })
    except Exception as e:
        logger.error(f"Erro na atualização de token: {str(e)}")
        return jsonify({'status': 'error', 'message': 'Erro interno do servidor'}), 500

@auth_bp.route('/me', methods=['GET'])
@jwt_required()
def get_user_profile():
    try:
        current_user_email = get_jwt_identity()
        
        if current_user_email not in users_db:
            logger.warning(f"Tentativa de acesso a perfil inexistente: {current_user_email}")
            return jsonify({'status': 'error', 'message': 'Usuário não encontrado'}), 404
        
        user = users_db[current_user_email]
        
        logger.info(f"Perfil acessado: {current_user_email}")
        
        return jsonify({
            'status': 'success',
            'user': {
                'id': user['id'],
                'email': current_user_email,
                'name': user['name'],
                'role': user['role'],
                'avatar': user['avatar'],
                'created_at': user['created_at'],
                'last_login': user['last_login'],
                'settings': user['settings']
            }
        })
    except Exception as e:
        logger.error(f"Erro ao acessar perfil: {str(e)}")
        return jsonify({'status': 'error', 'message': 'Erro interno do servidor'}), 500

@auth_bp.route('/me', methods=['PUT'])
@jwt_required()
def update_user_profile():
    try:
        current_user_email = get_jwt_identity()
        
        if current_user_email not in users_db:
            logger.warning(f"Tentativa de atualização de perfil inexistente: {current_user_email}")
            return jsonify({'status': 'error', 'message': 'Usuário não encontrado'}), 404
        
        data = request.get_json()
        
        if not data:
            return jsonify({'status': 'error', 'message': 'Dados inválidos'}), 400
        
        user = users_db[current_user_email]
        
        # Campos permitidos para atualização
        if 'name' in data:
            user['name'] = data['name']
        
        if 'avatar' in data:
            user['avatar'] = data['avatar']
        
        if 'settings' in data:
            # Atualizar apenas campos permitidos nas configurações
            settings = data['settings']
            if 'theme' in settings:
                user['settings']['theme'] = settings['theme']
            if 'notifications' in settings:
                user['settings']['notifications'] = settings['notifications']
            if 'language' in settings:
                user['settings']['language'] = settings['language']
        
        logger.info(f"Perfil atualizado: {current_user_email}")
        
        return jsonify({
            'status': 'success',
            'message': 'Perfil atualizado com sucesso',
            'user': {
                'id': user['id'],
                'email': current_user_email,
                'name': user['name'],
                'role': user['role'],
                'avatar': user['avatar'],
                'created_at': user['created_at'],
                'last_login': user['last_login'],
                'settings': user['settings']
            }
        })
    except Exception as e:
        logger.error(f"Erro ao atualizar perfil: {str(e)}")
        return jsonify({'status': 'error', 'message': 'Erro interno do servidor'}), 500

@auth_bp.route('/change-password', methods=['PUT'])
@jwt_required()
def change_password():
    try:
        current_user_email = get_jwt_identity()
        
        if current_user_email not in users_db:
            logger.warning(f"Tentativa de alteração de senha para usuário inexistente: {current_user_email}")
            return jsonify({'status': 'error', 'message': 'Usuário não encontrado'}), 404
        
        data = request.get_json()
        
        if not data or 'current_password' not in data or 'new_password' not in data:
            return jsonify({'status': 'error', 'message': 'Dados incompletos'}), 400
        
        current_password = data['current_password']
        new_password = data['new_password']
        
        user = users_db[current_user_email]
        
        # Verificar senha atual
        if not bcrypt.checkpw(current_password.encode('utf-8'), user['password'].encode('utf-8')):
            logger.warning(f"Tentativa de alteração de senha com senha atual incorreta: {current_user_email}")
            return jsonify({'status': 'error', 'message': 'Senha atual incorreta'}), 401
        
        # Validar nova senha
        is_valid, password_error = is_valid_password(new_password)
        if not is_valid:
            return jsonify({'status': 'error', 'message': password_error}), 400
        
        # Hash da nova senha
        hashed_password = bcrypt.hashpw(new_password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
        
        # Atualizar senha
        user['password'] = hashed_password
        
        # Invalidar todos os refresh tokens do usuário
        for token_id, token_data in list(refresh_tokens_db.items()):
            if token_data['user_email'] == current_user_email:
                refresh_tokens_db.pop(token_id, None)
        
        logger.info(f"Senha alterada: {current_user_email}")
        
        return jsonify({
            'status': 'success',
            'message': 'Senha alterada com sucesso'
        })
    except Exception as e:
        logger.error(f"Erro ao alterar senha: {str(e)}")
        return jsonify({'status': 'error', 'message': 'Erro interno do servidor'}), 500

@auth_bp.route('/logout', methods=['POST'])
@jwt_required()
def logout():
    try:
        current_user_email = get_jwt_identity()
        
        # Invalidar o token atual
        jti = get_jwt()["jti"]
        
        # Invalidar refresh token específico (se fornecido)
        data = request.get_json()
        if data and 'refresh_token' in data:
            refresh_token = data['refresh_token']
            if refresh_token in refresh_tokens_db:
                refresh_tokens_db.pop(refresh_token, None)
        
        logger.info(f"Logout realizado: {current_user_email}")
        
        return jsonify({
            'status': 'success',
            'message': 'Logout realizado com sucesso'
        })
    except Exception as e:
        logger.error(f"Erro no logout: {str(e)}")
        return jsonify({'status': 'error', 'message': 'Erro interno do servidor'}), 500

# Rota administrativa para gerenciar usuários (apenas para admins)
@auth_bp.route('/users', methods=['GET'])
@jwt_required()
def get_users():
    try:
        current_user_email = get_jwt_identity()
        
        if current_user_email not in users_db:
            logger.warning(f"Tentativa de acesso à lista de usuários por usuário inexistente: {current_user_email}")
            return jsonify({'status': 'error', 'message': 'Usuário não encontrado'}), 404
        
        current_user = users_db[current_user_email]
        
        # Verificar se é admin
        if current_user['role'] != 'admin':
            logger.warning(f"Tentativa de acesso à lista de usuários por usuário sem permissão: {current_user_email}")
            return jsonify({'status': 'error', 'message': 'Permissão negada'}), 403
        
        # Listar usuários (sem expor senhas)
        users_list = []
        for email, user in users_db.items():
            users_list.append({
                'id': user['id'],
                'email': email,
                'name': user['name'],
                'role': user['role'],
                'avatar': user['avatar'],
                'created_at': user['created_at'],
                'last_login': user['last_login'],
                'active': user['active']
            })
        
        logger.info(f"Lista de usuários acessada por: {current_user_email}")
        
        return jsonify({
            'status': 'success',
            'users': users_list
        })
    except Exception as e:
        logger.error(f"Erro ao listar usuários: {str(e)}")
        return jsonify({'status': 'error', 'message': 'Erro interno do servidor'}), 500

# Rota para recuperação de senha (simulada)
@auth_bp.route('/forgot-password', methods=['POST'])
def forgot_password():
    try:
        data = request.get_json()
        
        if not data or 'email' not in data:
            return jsonify({'status': 'error', 'message': 'Email é obrigatório'}), 400
        
        email = data['email'].lower()
        
        # Verificar se o email existe
        if email not in users_db:
            # Por segurança, não informamos se o email existe ou não
            logger.info(f"Solicitação de recuperação para email não cadastrado: {email}")
            return jsonify({
                'status': 'success',
                'message': 'Se o email estiver cadastrado, você receberá instruções para redefinir sua senha.'
            })
        
        # Em um sistema real, enviaríamos um email com um link para redefinição
        # Aqui, apenas simulamos o processo
        
        logger.info(f"Solicitação de recuperação de senha: {email}")
        
        return jsonify({
            'status': 'success',
            'message': 'Se o email estiver cadastrado, você receberá instruções para redefinir sua senha.'
        })
    except Exception as e:
        logger.error(f"Erro na recuperação de senha: {str(e)}")
        return jsonify({'status': 'error', 'message': 'Erro interno do servidor'}), 500
