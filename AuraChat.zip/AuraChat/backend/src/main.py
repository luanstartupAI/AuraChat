# src/main.py (Minimal Health Check Only)
import os
import sys
import logging
from datetime import datetime
from flask import Flask, jsonify
from flask_cors import CORS
from dotenv import load_dotenv

# Configuração de logging mínima
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler("aura_api_minimal.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Carregar variveis de ambiente (opcional para teste mínimo)
# load_dotenv()

# Inicializar aplicao Flask mínima
app = Flask(__name__)
CORS(app, resources={r"/api/*": {"origins": "*"}})

# Rota de verificao de sade única
@app.route("/api/health", methods=["GET"])
def health_check():
    logger.info("Minimal health check endpoint called.")
    return jsonify({
        "status": "success",
        "message": "Aura API (Minimal Health Check) is running",
        "version": "3.0.0-minimal-test",
        "timestamp": datetime.utcnow().isoformat() + "Z"
    })

if __name__ == "__main__":
    port = int(os.getenv("PORT", 5001))
    debug = os.getenv("FLASK_ENV", "production") == "development"
    
    logger.info(f"Iniciando Aura API Mínima na porta {port}, modo {"desenvolvimento" if debug else "produo"}")
    
    # Usar app.run padrão, sem SocketIO
    try:
        app.run(host="0.0.0.0", port=port, debug=debug, use_reloader=not debug)
    except Exception as e:
        logger.error(f"Failed to start minimal Flask app: {e}", exc_info=True)

